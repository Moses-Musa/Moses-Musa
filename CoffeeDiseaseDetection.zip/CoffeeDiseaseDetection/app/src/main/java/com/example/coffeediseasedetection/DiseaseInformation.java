package com.example.coffeediseasedetection;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.core.content.ContextCompat;

public class DiseaseInformation {
    private final int imageResId;
    private String name;
    private String causes;
    private String symptoms;
    private String preventiveMeasures;

    public DiseaseInformation(int imageResId, String name, String causes, String symptoms, String preventiveMeasures) {
        this.imageResId = imageResId;
        this.name = name;
        this.causes = causes;
        this.symptoms = symptoms;
        this.preventiveMeasures = preventiveMeasures;
    }

    public int getImageResId() {
        return imageResId;
    }

    public Drawable getImageDrawable(Context context) {
        // Load the image drawable from resources
        return ContextCompat.getDrawable(context, imageResId);
    }

    public String getName() {
        return name;
    }

    public String getCauses() {
        return causes;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public String getPreventiveMeasures() {
        return preventiveMeasures;
    }
}
