package com.example.coffeediseasedetection;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "DiagnosisDB";
    private static final int DATABASE_VERSION = 4; // Increment version when modifying the schema

    // Existing table for disease info
    private static final String TABLE_DISEASE_INFO = "DiseaseInfo";
    public static final String COLUMN_ID = "id";
    private static final String COLUMN_DISEASE_NAME = "disease_name";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_ORGANIC_CONTROL = "organic_control";
    private static final String COLUMN_CHEMICAL_CONTROL = "chemical_control";

    // Existing table for disease information
    private static final String TABLE_DISEASE_INFORMATION = "DiseaseInformation";
    private static final String COLUMN_INFO_ID = "info_id";
    static final String COLUMN_DISEASE_NAME_INFO = "disease_name_info";
    static final String COLUMN_IMAGE = "image";
    static final String COLUMN_CAUSES = "causes";
    static final String COLUMN_SYMPTOMS = "symptoms";
    static final String COLUMN_PREVENTIVE_MEASURES = "preventive_measures";

    // Existing table for farming information
    private static final String TABLE_FARMING_INFORMATION = "FarmingInformation";
    private static final String COLUMN_FARMING_ID = "farming_id";
    private static final String COLUMN_CLIMATIC_CONDITIONS = "climatic_conditions";
    private static final String COLUMN_LAND_PREPARATION = "land_preparation";
    private static final String COLUMN_SELECTION_OF_SEEDLINGS = "selection_of_seedlings";
    private static final String COLUMN_DIGGING_OF_HOLES = "digging_of_holes";
    private static final String COLUMN_PLANTING_OF_SEEDLINGS = "planting_of_seedlings";
    private static final String COLUMN_MULCHING = "mulching";
    private static final String COLUMN_WATERING = "watering";
    private static final String COLUMN_PRUNING = "pruning";

    // New table for history information
    static final String TABLE_HISTORY = "History";
    public static final String COLUMN_HISTORY_ID = "history_id";
    static final String COLUMN_TIMESTAMP = "timestamp";
    static final String COLUMN_RECOMMENDATIONS = "recommendations";
    static final String COLUMN_CONFIDENCE = "confidence";
    static final String COLUMN_ORGANIC_CONTROL1 = "organiccontrol";
    static final String COLUMN_CHEMICAL_CONTROL1 = "chemicalcontrol";

    private static final String CREATE_TABLE_HISTORY = "CREATE TABLE " + TABLE_HISTORY + " ("
            + COLUMN_HISTORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_DISEASE_NAME_INFO + " TEXT,"
            + COLUMN_IMAGE + " BLOB,"
            + COLUMN_RECOMMENDATIONS + " TEXT,"
            + COLUMN_ORGANIC_CONTROL1 + " TEXT,"
            + COLUMN_CHEMICAL_CONTROL1 + " TEXT,"
            + COLUMN_CONFIDENCE + " TEXT,"
            + COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";

    private static final String CREATE_TABLE_FARMING_INFORMATION = "CREATE TABLE " + TABLE_FARMING_INFORMATION + " ("
            + COLUMN_FARMING_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_CLIMATIC_CONDITIONS + " TEXT,"
            + COLUMN_LAND_PREPARATION + " TEXT,"
            + COLUMN_SELECTION_OF_SEEDLINGS + " TEXT,"
            + COLUMN_DIGGING_OF_HOLES + " TEXT,"
            + COLUMN_PLANTING_OF_SEEDLINGS + " TEXT,"
            + COLUMN_MULCHING + " TEXT,"
            + COLUMN_WATERING + " TEXT,"
            + COLUMN_PRUNING + " TEXT"
            + ")";

    private static final String CREATE_TABLE_DISEASE_INFO = "CREATE TABLE " + TABLE_DISEASE_INFO + " ("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_DISEASE_NAME + " TEXT,"
            + COLUMN_DESCRIPTION + " TEXT,"
            + COLUMN_ORGANIC_CONTROL + " TEXT,"
            + COLUMN_CHEMICAL_CONTROL + " TEXT"
            + ")";

    private static final String CREATE_TABLE_DISEASE_INFORMATION = "CREATE TABLE " + TABLE_DISEASE_INFORMATION + " ("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_DISEASE_NAME_INFO + " TEXT,"
            + COLUMN_IMAGE + " INTEGER,"
            + COLUMN_CAUSES + " TEXT,"
            + COLUMN_SYMPTOMS + " TEXT,"
            + COLUMN_PREVENTIVE_MEASURES + " TEXT"
            + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_DISEASE_INFO);
        db.execSQL(CREATE_TABLE_DISEASE_INFORMATION);
        db.execSQL(CREATE_TABLE_FARMING_INFORMATION);
        db.execSQL(CREATE_TABLE_HISTORY); // Add the creation of the history table
        // Manually insert disease information
        insertDiseaseInfo(db, "miner", "Use organic control methods in the early stages of a disease or when crop is close to harvesting. In more advanced stages of the disease be sure to choose an insecticide that is labeled for use on coffee plants and follow the application instructions carefully", "Pheromones can be used to manipulate or disrupt the natural behaviors of insects to reduce population levels", "Always consider an integrated approach along with preventive measures and available biological treatments. Currently, coffee growers use neurotoxic insecticides, such as organophosphates, carbamates, pyrethroids, neonicotinoids, and diamides. However, chemical controls are insufficient and can lose their effectiveness because their use can lead to pest resistance");
        insertDiseaseInfo(db, "rust", "Use organic control methods in the early stages of a disease or when crop is close to harvesting. In more advanced stages, be sure to choose an insecticide that is labeled for use on coffee plants and follow the application instructions carefully. Apply Copper-based fungicides: Bordeaux mixture and cuprous oxide. Apply before the rainy season or at the first sign of infection...", "Commercial biocontrol strategies for controlling the disease are not highly available. Taking prevention into account will provide the most significant results in controlling the disease.", "Always consider an integrated approach along with preventive measures and available biological treatments. Prophylactic spraying of Bordeaux mixture of Copper Oxychloride 50% WG can be done, once before the occurrence of favorable environmental factors to the disease and again after the cessation of this period.");
        insertDiseaseInfo(db, "healthy", "The plant is healthy, ensure good agricultural practices for better yields...", "Practice organic control methods to prevent the occurrence of diseases. This acts as a preventative measure", "Always consider an integrated approach along with preventive measures and available biological treatments. Currently, coffee growers use neurotoxic insecticides, such as organophosphates, carbamates, pyrethroids, neonicotinoids, and diamides. However, chemical controls are insufficient and can lose their effectiveness because their use can lead to pest resistance");
        insertDiseaseInformation(db, "coffee_leaf_miner", R.drawable.miner, "Caused by an insect called Leucoptera sp.",
                "Irregular brown spots on the upper leaf surface, Pale yellow trails under the coffee leaf epidermis, Presence of large necrotic patches",
                "Use organic control methods in the early stages of the disease or when the crop is close to harvesting. In more advanced stages, use an insecticide that is labeled for use on coffee plants and follow the application instructions carefully.");

        insertDiseaseInformation(db, "coffee_leaf_rust", R.drawable.rust, "Caused by a fungus called Hemileia vastatrix",
                "Small yellowish and blotchy spots on the lower side of the leaf, Corresponding chlorotic patches on the upper side",
                "Use organic control methods in the early stages of the disease or when the crop is close to harvesting. In more advanced stages, use an insecticide that is labeled for use on coffee plants and follow the application instructions carefully. Apply copper-based fungicides before the rainy season or at the first sign of infection.");

        insertFarmingInformation(db, "Growing coffee requires specific climatic, soil, and water conditions. It is a tropical crop that thrives in areas with warm temperatures, abundant rainfall, and well-drained soil. The ideal temperature range for coffee growth is between 15-24 degrees Celsius. In terms of rainfall, coffee plants require a lot of water. The ideal rainfall range is between 1200mm and 1800mm well distributed over a period of nine months, with consistent rainfall throughout the growing season.",
                "The land must be cleared of any existing vegetation, rocks, and other debris. The soil should then be tilled to a depth of at least 30cm to loosen and aerate it.",
                "High-quality coffee seedlings should be selected from a reputable nursery or developed from seeds at least six months old.",
                "Holes should be dug at least 60cm deep and 60cm wide enough to accommodate the root ball of the seedling. The holes should be 3 meters apart.",
                "The seedlings should be carefully placed in the center of the hole. The soil in the hole should be uniformly mixed with well-decomposed manure to boost growth and root establishment.",
                "A layer of organic mulch should be applied around the base of the seedling to help retain moisture and suppress weed growth. Mulching regulates soil moisture, controls soil erosion, and helps retain water.",
                "The newly planted seedlings should be watered immediately and regularly to ensure that the soil remains moist but not waterlogged. In dry spells or when the rains aren't regular, water bottle irrigation can be used as a cheap means.",
                "At a later stage when the plant has grown, pruning should be done to remove any weak, dead, unproductive, diseased and broken branches and promote the growth of a strong central system. It should be carried out at the end of the harvesting season just before flowering takes place.");
    }

    private void insertFarmingInformation(SQLiteDatabase db, String climaticConditions, String landPreparation, String selectionOfSeedlings,
                                          String diggingOfHoles, String plantingOfSeedlings, String mulching, String watering, String pruning) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_CLIMATIC_CONDITIONS, climaticConditions);
        values.put(COLUMN_LAND_PREPARATION, landPreparation);
        values.put(COLUMN_SELECTION_OF_SEEDLINGS, selectionOfSeedlings);
        values.put(COLUMN_DIGGING_OF_HOLES, diggingOfHoles);
        values.put(COLUMN_PLANTING_OF_SEEDLINGS, plantingOfSeedlings);
        values.put(COLUMN_MULCHING, mulching);
        values.put(COLUMN_WATERING, watering);
        values.put(COLUMN_PRUNING, pruning);
        db.insert(TABLE_FARMING_INFORMATION, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DISEASE_INFO);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DISEASE_INFORMATION);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FARMING_INFORMATION);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HISTORY);
        onCreate(db);
    }

    private void insertDiseaseInfo(SQLiteDatabase db, String diseaseName, String description, String organicControl, String chemicalControl) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_DISEASE_NAME, diseaseName);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_ORGANIC_CONTROL, organicControl);
        values.put(COLUMN_CHEMICAL_CONTROL, chemicalControl);
        db.insert(TABLE_DISEASE_INFO, null, values);
    }

    private void insertDiseaseInformation(SQLiteDatabase db, String diseaseName, int imageResId, String causes, String symptoms, String preventiveMeasures) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_DISEASE_NAME_INFO, diseaseName);
        values.put(COLUMN_IMAGE, imageResId);  // Store the resource identifier
        values.put(COLUMN_CAUSES, causes);
        values.put(COLUMN_SYMPTOMS, symptoms);
        values.put(COLUMN_PREVENTIVE_MEASURES, preventiveMeasures);
        db.insert(TABLE_DISEASE_INFORMATION, null, values);
    }

    public void insertHistory(String diseaseName, byte[] image, String recommendations, String organiccontrol, String chemicalcontrol, String confidence, String timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_DISEASE_NAME_INFO, diseaseName);
        values.put(COLUMN_IMAGE, image);
        values.put(COLUMN_RECOMMENDATIONS, recommendations);
        values.put(COLUMN_ORGANIC_CONTROL1, organiccontrol);
        values.put(COLUMN_CHEMICAL_CONTROL1, chemicalcontrol);
        values.put(COLUMN_CONFIDENCE, confidence);
        values.put(COLUMN_TIMESTAMP, timestamp);

        db.insert(TABLE_HISTORY, null, values);

        db.close();
    }


    public String getDiseaseDescription(String diseaseName) {
        return getDiseaseInfo(diseaseName, COLUMN_DESCRIPTION);
    }

    public String getOrganicControl(String diseaseName) {
        return getDiseaseInfo(diseaseName, COLUMN_ORGANIC_CONTROL);
    }

    public String getChemicalControl(String diseaseName) {
        return getDiseaseInfo(diseaseName, COLUMN_CHEMICAL_CONTROL);
    }

    private String getDiseaseInfo(String diseaseName, String columnName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {columnName};
        String selection = COLUMN_DISEASE_NAME + " = ?";
        String[] selectionArgs = {diseaseName};

        Cursor cursor = db.query(TABLE_DISEASE_INFO, columns, selection, selectionArgs, null, null, null);

        String info = "";
        if (cursor.moveToFirst()) {
            info = cursor.getString(cursor.getColumnIndexOrThrow(columnName));
        }

        cursor.close();
        db.close();
        return info;
    }

    public String getClimaticConditions() {
        return getFarmingInfo(COLUMN_CLIMATIC_CONDITIONS);
    }

    public String getLandPreparation() {
        return getFarmingInfo(COLUMN_LAND_PREPARATION);
    }

    public String getSelectionOfSeedlings() {
        return getFarmingInfo(COLUMN_SELECTION_OF_SEEDLINGS);
    }

    public String getDiggingOfHoles() {
        return getFarmingInfo(COLUMN_DIGGING_OF_HOLES);
    }

    public String getPlantingOfSeedlings() {
        return getFarmingInfo(COLUMN_PLANTING_OF_SEEDLINGS);
    }

    public String getMulching() {
        return getFarmingInfo(COLUMN_MULCHING);
    }

    public String getWatering() {
        return getFarmingInfo(COLUMN_WATERING);
    }

    public String getPruning() {
        return getFarmingInfo(COLUMN_PRUNING);
    }

    private String getFarmingInfo(String columnName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {columnName};
        Cursor cursor = db.query(TABLE_FARMING_INFORMATION, columns, null, null, null, null, null);

        String info = "";
        if (cursor.moveToFirst()) {
            info = cursor.getString(cursor.getColumnIndexOrThrow(columnName));
        }

        cursor.close();
        db.close();
        return info;
    }

    // Inside DatabaseHelper class
    public DiseaseInformation getDiseaseInformation(String diseaseName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_IMAGE, COLUMN_DISEASE_NAME_INFO, COLUMN_CAUSES, COLUMN_SYMPTOMS, COLUMN_PREVENTIVE_MEASURES};
        String selection = COLUMN_DISEASE_NAME_INFO + " = ?";
        String[] selectionArgs = {diseaseName};

        Cursor cursor = db.query(TABLE_DISEASE_INFORMATION, columns, selection, selectionArgs, null, null, null);

        DiseaseInformation diseaseInformation = null;
        if (cursor.moveToFirst()) {
            int imageResId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IMAGE));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DISEASE_NAME_INFO));
            String causes = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CAUSES));
            String symptoms = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SYMPTOMS));
            String preventiveMeasures = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PREVENTIVE_MEASURES));

            diseaseInformation = new DiseaseInformation(imageResId, name, causes, symptoms, preventiveMeasures);
        }

        cursor.close();
        db.close();

        return diseaseInformation;
    }
    public List<String> getAllDiseaseNames() {
        List<String> diseaseNames = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_DISEASE_NAME_INFO};
        Cursor cursor = db.query(true, TABLE_DISEASE_INFORMATION, columns, null, null, null, null, null, null);

        while (cursor.moveToNext()) {
            String diseaseName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DISEASE_NAME_INFO));
            diseaseNames.add(diseaseName);
        }

        cursor.close();
        db.close();
        return diseaseNames;
    }


    // New method to insert history information
    public void insertHistoryInfo(String diseaseName, byte[] image, String recommendations, String organiccontrol, String chemicalcontrol, String confidence) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DISEASE_NAME_INFO, diseaseName);
        values.put(COLUMN_IMAGE, image);
        values.put(COLUMN_RECOMMENDATIONS, recommendations);
        values.put(COLUMN_ORGANIC_CONTROL1, organiccontrol);
        values.put(COLUMN_CHEMICAL_CONTROL1, chemicalcontrol);
        values.put(COLUMN_CONFIDENCE, confidence);
        values.put(COLUMN_TIMESTAMP, getCurrentTimestamp());  // Add this line
        db.insert(TABLE_HISTORY, null, values);
        db.close();
    }

    // New method to get all history entries
    public List<HistoryEntry> getAllHistoryEntries() {
        List<HistoryEntry> historyEntries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_HISTORY_ID, COLUMN_DISEASE_NAME_INFO, COLUMN_RECOMMENDATIONS, COLUMN_ORGANIC_CONTROL1, COLUMN_CHEMICAL_CONTROL1, COLUMN_CONFIDENCE, COLUMN_TIMESTAMP};
        Cursor cursor = db.query(TABLE_HISTORY, columns, null, null, null, null, COLUMN_TIMESTAMP + " DESC");

        while (cursor.moveToNext()) {
            int historyId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_HISTORY_ID));
            String diseaseName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DISEASE_NAME_INFO));
            String recommendations = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_RECOMMENDATIONS));
            String organicControl = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ORGANIC_CONTROL1));
            String chemicalControl = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CHEMICAL_CONTROL1));
            String confidence = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CONFIDENCE));
            String timestamp = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP));

            HistoryEntry entry = new HistoryEntry(historyId, diseaseName, recommendations, organicControl, chemicalControl, confidence, timestamp);
            historyEntries.add(entry);
        }

        cursor.close();
        db.close();
        return historyEntries;
    }

    // New helper method to get current timestamp
    public String getCurrentTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }
}
