package com.example.coffeediseasedetection;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.io.IOException;
import java.io.InputStream;

public class homepage extends AppCompatActivity {

    CardView diseaseinfo;
    CardView farminginfo;
    CardView camera;
    CardView gallery;
    CardView net;
    CardView history;

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_PICK_IMAGE = 2;

    private static final int TARGET_IMAGE_SIZE = 256;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        diseaseinfo = findViewById(R.id.diseaseinfo);
        farminginfo = findViewById(R.id.farminginfo);
        camera = findViewById(R.id.camera);
        history = findViewById(R.id.history);
        gallery = findViewById(R.id.gallery);
        net = findViewById(R.id.net);

        net.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Define the URL of the webpage
                String url = "https://plantvillage.psu.edu/topics/coffee/infos";

                // Create an Intent with ACTION_VIEW and the webpage URL
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));

                // Start the activity to view the webpage
                startActivity(intent);
            }
        });


        diseaseinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the next activity when the button is clicked
                Intent intent = new Intent(homepage.this, DiseaseInfo.class);
                startActivity(intent);
            }
        });
        farminginfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              Intent intent = new Intent(homepage.this, FarmingInfo.class);
              startActivity(intent);
            }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(homepage.this, History.class);
                startActivity(intent);
            }
        });

        camera.setOnClickListener(view -> {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
            } else {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, 100);
            }
        });

        gallery.setOnClickListener(view -> {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, REQUEST_PICK_IMAGE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                if (data != null && data.getExtras() != null) {
                    Bitmap capturedImage = (Bitmap) data.getExtras().get("data");
                    // Resize the image
                    Bitmap resizedImage = resizeImage(capturedImage, TARGET_IMAGE_SIZE, TARGET_IMAGE_SIZE);
                    handleImage(resizedImage);
                } else {
                    Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == REQUEST_PICK_IMAGE) {
                if (data != null && data.getData() != null) {
                    Uri selectedImageUri = data.getData();
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(selectedImageUri);
                        Bitmap selectedImage = BitmapFactory.decodeStream(inputStream);
                        // Resize the image
                        Bitmap resizedImage = resizeImage(selectedImage, TARGET_IMAGE_SIZE, TARGET_IMAGE_SIZE);
                        handleImage(resizedImage);
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Failed to load selected image", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }

    private void handleImage(Bitmap image) {
        // Start MainActivity and pass the image
        Intent intent = new Intent(homepage.this, MainActivity.class);
        intent.putExtra("image", image);
        startActivity(intent);
    }

    private Bitmap resizeImage(Bitmap image, int targetWidth, int targetHeight) {
        return Bitmap.createScaledBitmap(image, targetWidth, targetHeight, true);
    }
}
