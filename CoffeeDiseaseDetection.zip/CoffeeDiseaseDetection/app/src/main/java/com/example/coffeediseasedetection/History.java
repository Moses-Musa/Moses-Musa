package com.example.coffeediseasedetection;

import static com.example.coffeediseasedetection.DatabaseHelper.COLUMN_CHEMICAL_CONTROL1;
import static com.example.coffeediseasedetection.DatabaseHelper.COLUMN_CONFIDENCE;
import static com.example.coffeediseasedetection.DatabaseHelper.COLUMN_DISEASE_NAME_INFO;
import static com.example.coffeediseasedetection.DatabaseHelper.COLUMN_IMAGE;
import static com.example.coffeediseasedetection.DatabaseHelper.COLUMN_ORGANIC_CONTROL1;
import static com.example.coffeediseasedetection.DatabaseHelper.COLUMN_RECOMMENDATIONS;
import static com.example.coffeediseasedetection.DatabaseHelper.COLUMN_TIMESTAMP;
import static com.example.coffeediseasedetection.DatabaseHelper.TABLE_HISTORY;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class History extends AppCompatActivity {

    ImageView imageViewhistory, nexthistory, delete;
    TextView resulthistory, recommendations1, organiccontrol1, chemicalcontrol1, confidencehistory, datee;

    private Cursor historyCursor;
    private int currentHistoryIndex = -1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        imageViewhistory = findViewById(R.id.imageViewhistory);
        nexthistory = findViewById(R.id.nexthistory);
        datee = findViewById(R.id.datee);
        delete = findViewById(R.id.delete);
        resulthistory = findViewById(R.id.resulthistory);
        recommendations1 = findViewById(R.id.recommendations1);
        organiccontrol1 = findViewById(R.id.organiccontrol1);
        chemicalcontrol1 = findViewById(R.id.chemicalcontrol1);
        confidencehistory = findViewById(R.id.confidencehistory);

        // Retrieve and display history information
        displayNextHistory();

        // Set a click listener for the nexthistory ImageView
        nexthistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayNextHistory();
            }
        });

        // Set a click listener for the delete ImageView
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (historyCursor != null && historyCursor.getCount() > 0) {
                    // Get the ID of the current history entry
                    int idIndex = historyCursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_HISTORY_ID);
                    int currentHistoryId = historyCursor.getInt(idIndex);


                    // Delete the current history entry from the database
                    DatabaseHelper dbHelper = new DatabaseHelper(History.this);
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    db.delete(DatabaseHelper.TABLE_HISTORY, DatabaseHelper.COLUMN_HISTORY_ID + "=?", new String[]{String.valueOf(currentHistoryId)});
                    db.close();

                    // Display a toast message indicating that the history entry has been deleted
                    Toast.makeText(History.this, "Deleted", Toast.LENGTH_SHORT).show();

                    // Display the next history entry
                    displayNextHistory();
                }
            }
        });
    }

    private void displayNextHistory() {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Query the history table to get all history entries in descending order of timestamp
        String query = "SELECT * FROM " + TABLE_HISTORY + " ORDER BY " + COLUMN_TIMESTAMP + " DESC";
        historyCursor = db.rawQuery(query, null);

        if (historyCursor.moveToNext()) {
            // Move the cursor to the next history entry
            historyCursor.moveToPosition(++currentHistoryIndex);

            // Check if we reached the end, go back to the first history entry
            if (currentHistoryIndex >= historyCursor.getCount()) {
                currentHistoryIndex = 0;
                historyCursor.moveToFirst();
            }

            // Retrieve information from the cursor
            String diseaseName = historyCursor.getString(historyCursor.getColumnIndexOrThrow(COLUMN_DISEASE_NAME_INFO));
            byte[] imageBytes = historyCursor.getBlob(historyCursor.getColumnIndexOrThrow(COLUMN_IMAGE));
            Bitmap image = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            String recommendations = historyCursor.getString(historyCursor.getColumnIndexOrThrow(COLUMN_RECOMMENDATIONS));
            String organiccontrol = historyCursor.getString(historyCursor.getColumnIndexOrThrow(COLUMN_ORGANIC_CONTROL1));
            String chemicalcontrol = historyCursor.getString(historyCursor.getColumnIndexOrThrow(COLUMN_CHEMICAL_CONTROL1));
            String confidence = historyCursor.getString(historyCursor.getColumnIndexOrThrow(COLUMN_CONFIDENCE));
            String timestamp = historyCursor.getString(historyCursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP));

            // Display information in the UI
            imageViewhistory.setImageBitmap(image);
            resulthistory.setText(diseaseName);
            datee.setText("Date: " + timestamp); // Update datee TextView

            // Display other information as needed
            recommendations1.setText(recommendations);
            organiccontrol1.setText(organiccontrol);
            chemicalcontrol1.setText(chemicalcontrol);
            confidencehistory.setText(confidence);

            // Display other information as needed
            // ...

        } else {
            // If there are no more history entries, close the cursor
            currentHistoryIndex = -1;
            historyCursor.close();
        }

        db.close();
    }
}
