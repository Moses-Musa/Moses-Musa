package com.example.coffeediseasedetection;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class DiseaseInfo extends AppCompatActivity {
    ImageView imageView, next;
    TextView diseasename, causes, symptoms, preventivemeasures;
    List<String> allDiseaseNames;
    int currentDiseaseIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disease_info);

        // Initialize views
        imageView = findViewById(R.id.imageView);
        diseasename = findViewById(R.id.diseasename);
        causes = findViewById(R.id.causes);
        symptoms = findViewById(R.id.symptoms);
        next = findViewById(R.id.next);
        preventivemeasures = findViewById(R.id.preventivemeasures);

        // Get all disease names from the database
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        allDiseaseNames = databaseHelper.getAllDiseaseNames();

        // Set the current disease index to 0
        currentDiseaseIndex = 0;

        // Display disease information for the first disease
        displayDiseaseInformation(allDiseaseNames.get(currentDiseaseIndex));

        // Set click listener for the "Next" button
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Increment the current index
                currentDiseaseIndex++;

                // Check if we reached the end, go back to the beginning
                if (currentDiseaseIndex >= allDiseaseNames.size()) {
                    currentDiseaseIndex = 0;
                }

                // Display disease information for the next disease
                displayDiseaseInformation(allDiseaseNames.get(currentDiseaseIndex));
            }
        });
    }

    // Method to display disease information
    private void displayDiseaseInformation(String diseaseName) {
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        DiseaseInformation diseaseInformation = databaseHelper.getDiseaseInformation(diseaseName);

        if (diseaseInformation != null) {
            // Load the image drawable
            imageView.setImageDrawable(diseaseInformation.getImageDrawable(this));

            diseasename.setText(diseaseInformation.getName());
            causes.setText(diseaseInformation.getCauses());
            symptoms.setText(diseaseInformation.getSymptoms());
            preventivemeasures.setText(diseaseInformation.getPreventiveMeasures());
        }
    }

}
