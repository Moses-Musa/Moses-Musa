package com.example.coffeediseasedetection;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.coffeediseasedetection.ml.ConvertedModel;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    TextView result, recommendation, organiccontrol, chemicalcontrol, confidence;
    int imageSize = 256;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        result = findViewById(R.id.result);
        recommendation = findViewById(R.id.recommendations);
        organiccontrol = findViewById(R.id.organiccontrol);
        chemicalcontrol = findViewById(R.id.chemicalcontrol);
        confidence = findViewById(R.id.confidence);

        dbHelper = new DatabaseHelper(this);

        // Receive the image from the homepage
        // Retrieve image from Intent
        Intent intent = getIntent();
        if (intent != null) {
            if (intent.hasExtra("image")) {
                Bitmap image = intent.getParcelableExtra("image");
                displayAndClassifyImage(image);
            }
        }
    }

    private void displayAndClassifyImage(Bitmap image) {
        // Check if the image is green in color
        if (isImageGreen(image)) {
            // Display the captured image
            imageView.setImageBitmap(image);

            // Now you can perform any additional processing or UI updates based on the captured image
            // Call your classifyImage() method or any other logic here.
            classifyImage(image);
        } else {
            // Display a message if the image is not green
            Toast.makeText(this, "Please capture a coffee leaf image", Toast.LENGTH_LONG).show();

            finish();
        }
    }

    private boolean isImageGreen(Bitmap image) {
        // Sample a few pixels from the image and check if they are predominantly green
        int sampleSize = 7; // You can adjust the sample size based on your preference
        int totalGreenPixels = 0;

        int width = image.getWidth();
        int height = image.getHeight();

        int[] pixels = new int[sampleSize * sampleSize];
        image.getPixels(pixels, 0, sampleSize, width / 2, height / 2, sampleSize, sampleSize);

        for (int pixel : pixels) {
            int green = Color.green(pixel);
            int red = Color.red(pixel);
            int blue = Color.blue(pixel);

            // Check if green is the dominant color
            if (green > red && green > blue) {
                totalGreenPixels++;
            }
        }

        // Consider the image green if a certain percentage of sampled pixels are green
        double greenPercentage = (double) totalGreenPixels / (double) (sampleSize * sampleSize);
        return greenPercentage > 0.6; // Adjust this threshold based on your needs
    }

    public void classifyImage(Bitmap image) {
        try {
            ConvertedModel model = ConvertedModel.newInstance(getApplicationContext());

            // Creates inputs for reference.
            TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 256, 256, 3}, DataType.FLOAT32);
            ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * imageSize * imageSize * 3);
            byteBuffer.order(ByteOrder.nativeOrder());

            int[] intValues = new int[imageSize * imageSize];
            image.getPixels(intValues, 0, image.getWidth(), 0, 0, image.getWidth(), image.getHeight());
            int pixel = 0;
            // Iterate over each pixel and extract R, G, and B values. Add those values individually to the byte buffer.
            for (int i = 0; i < imageSize; i++) {
                for (int j = 0; j < imageSize; j++) {
                    int val = intValues[pixel++]; // RGB
                    byteBuffer.putFloat(((val >> 16) & 0xFF) * (1.f));
                    byteBuffer.putFloat(((val >> 8) & 0xFF) * (1.f));
                    byteBuffer.putFloat((val & 0xFF) * (1.f));
                }
            }

            inputFeature0.loadBuffer(byteBuffer);

            // Runs model inference and gets result.
            ConvertedModel.Outputs outputs = model.process(inputFeature0);
            TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

            float[] confidences = outputFeature0.getFloatArray();
            // Find the index of the class with the biggest confidence.
            int maxPos = 0;
            float maxConfidence = 0;
            for (int i = 0; i < confidences.length; i++) {
                if (confidences[i] > maxConfidence) {
                    maxConfidence = confidences[i];
                    maxPos = i;
                }
            }

            String[] classes = {"healthy", "miner", "rust"};
            String predictedDisease = classes[maxPos];
            float confidenceValue = maxConfidence * 100; // Convert confidence to percentage
            String confidenceText = "Confidence: " + String.format("%.2f", confidenceValue) + "%";
            result.setText(predictedDisease);
            confidence.setText(confidenceText);

            // Retrieve additional information from the database
            String diseaseDescription = dbHelper.getDiseaseDescription(predictedDisease);
            String organicControl = dbHelper.getOrganicControl(predictedDisease);
            String chemicalControl = dbHelper.getChemicalControl(predictedDisease);

            // Create a clickable link within the disease description text
            SpannableString spannableString = new SpannableString("Get More information here...");
            ClickableSpan clickableSpan = new ClickableSpan() {
                @Override
                public void onClick(@NonNull View widget) {
                    // Handle link click, for example, open a URL
                    String url = "https://plantvillage.psu.edu/topics/coffee/infos"; // Replace with your URL
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                }
            };
            spannableString.setSpan(clickableSpan, 0, spannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            // Set the color of the clickable text to blue
            spannableString.setSpan(new ForegroundColorSpan(Color.BLUE), 0, spannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            // Combine the disease description and the clickable link
            SpannableStringBuilder builder = new SpannableStringBuilder();
            builder.append(diseaseDescription).append(" ").append(spannableString);

            // Display the text in the recommendation TextView
            recommendation.setText(builder);
            recommendation.setMovementMethod(LinkMovementMethod.getInstance()); // Enable clickable links

            // Display organic control and chemical control information
            organiccontrol.setText("Organic Control: " + organicControl);
            chemicalcontrol.setText("Chemical Control: " + chemicalControl);

            // Save the classification information to the history table
            saveToHistory(predictedDisease, image, recommendation.getText().toString(), organiccontrol.getText().toString(), chemicalcontrol.getText().toString(), confidence.getText().toString());


            // Releases model resources if no longer used.
            model.close();

        } catch (IOException e) {
            // TODO Handle the exception
        }
    }

    private void saveToHistory(String diseaseName, Bitmap image, String recommendations, String organiccontrol, String chemicalcontrol, String confidence) {
        // Convert Bitmap to byte array
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();

        // Get current timestamp
        String timestamp = dbHelper.getCurrentTimestamp();

        // Insert data into history table
        dbHelper.insertHistory(diseaseName, byteArray, recommendations, organiccontrol, chemicalcontrol, confidence, timestamp);
    }
}
