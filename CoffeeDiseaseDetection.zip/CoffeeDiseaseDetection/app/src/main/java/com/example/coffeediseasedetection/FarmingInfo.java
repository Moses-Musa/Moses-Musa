package com.example.coffeediseasedetection;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class FarmingInfo extends AppCompatActivity {
    ImageView coffee;
    TextView climatic, land, seedlings, digging, planting, mulching, watering, pruning;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farming_info);

        // Initialize views
        coffee = findViewById(R.id.coffee);
        climatic = findViewById(R.id.climatic);
        land = findViewById(R.id.land);
        seedlings = findViewById(R.id.seedlings);
        digging = findViewById(R.id.digging);
        planting = findViewById(R.id.planting);
        mulching = findViewById(R.id.mulching);
        watering = findViewById(R.id.watering);
        pruning = findViewById(R.id.pruning);

        coffee.setImageResource(R.drawable.background);
        LayoutParams layoutParams = new LayoutParams(388, ViewGroup.LayoutParams.WRAP_CONTENT);
        coffee.setLayoutParams(layoutParams);
        // Retrieve farming information from the database
        DatabaseHelper databaseHelper = new DatabaseHelper(this);

        climatic.setText(databaseHelper.getClimaticConditions());
        land.setText(databaseHelper.getLandPreparation());
        seedlings.setText(databaseHelper.getSelectionOfSeedlings());
        digging.setText(databaseHelper.getDiggingOfHoles());
        planting.setText(databaseHelper.getPlantingOfSeedlings());
        mulching.setText(databaseHelper.getMulching());
        watering.setText(databaseHelper.getWatering());
        pruning.setText(databaseHelper.getPruning());
    }
}
