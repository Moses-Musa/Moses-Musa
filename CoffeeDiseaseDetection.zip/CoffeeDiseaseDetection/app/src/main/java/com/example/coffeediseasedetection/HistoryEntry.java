package com.example.coffeediseasedetection;

public class HistoryEntry {
    private int historyId;
    private String diseaseName;
    private byte[] image;
    private String recommendations;
    private String organiccontrol;
    private String chemicalcontrol;
    private String timestamp;
    private String confidence;

    public HistoryEntry(int historyId, String diseaseName, String recommendations, String organiccontrol, String chemicalcontrol, String confidence, String timestamp) {
        this.historyId = historyId;
        this.diseaseName = diseaseName;
        this.image = image;
        this.recommendations = recommendations;
        this.organiccontrol = organiccontrol;
        this.chemicalcontrol = chemicalcontrol;
        this.confidence = confidence;
        this.timestamp = timestamp;
    }

    public int getHistoryId() {
        return historyId;
    }

    public String getDiseaseName() {
        return diseaseName;
    }

    public byte[] getImage() {
        return image;
    }

    public String getCauses() {
        return recommendations;
    }

    public String getSymptoms() {
        return organiccontrol;
    }

    public String getPreventiveMeasures() {
        return chemicalcontrol;
    }
    public String getConfidence() {
        return confidence;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
